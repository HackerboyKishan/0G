EXPLORER_URL_0G = "https://chainscan-newton.0g.ai/tx/0x"
